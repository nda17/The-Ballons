$(document).ready(function () {
    $('.nav').click(function (event) {
        $('.nav, .nav-main, .nav-main-list').toggleClass('active');
    });
});

